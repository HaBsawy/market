<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Market</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset("css/all.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
    <link rel="icon" href="<?php echo e(asset("images/h.jpg")); ?>">
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: 'Josefin Sans', sans-serif;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <?php if($auth ?? ''): ?>
        <div id="auth" style="display: none"
             data-username="<?php echo e($auth['username']); ?>"
             data-email="<?php echo e($auth['email']); ?>"
             data-role="<?php echo e($auth['role']); ?>"
        ><?php echo e($auth['token'] ?? '1'); ?></div>
        <div id="time" style="display: none"><?php echo e($mod_date ?? '1'); ?></div>
    <?php endif; ?>
    <div id="app">
        <router-view></router-view>
    </div>

    <script src="<?php echo e(asset("js/app.js")); ?>"></script>
    <script>
        let auth = document.getElementById('auth');
        if (auth) {
            let time = document.getElementById('time').innerText,
                token = auth.innerText,
                username = auth.getAttribute('data-username'),
                email = auth.getAttribute('data-email'),
                role = auth.getAttribute('data-role');

            localStorage.setItem('token', token);
            localStorage.setItem('time', time);
            localStorage.setItem('username', username);
            localStorage.setItem('email', email);
            localStorage.setItem('role', role);

            window.location.href = "http://localhost:8000";
        }
    </script>
</body>
</html>
<?php /**PATH E:\Projects\market\resources\views/app.blade.php ENDPATH**/ ?>